# Project brief template

Use this template when starting a new animated story. The user may leave fields blank; choose sensible defaults rather than asking many questions.

- Story/topic:
- Duration:
- Aspect ratio: 9:16 (default)
- Character description:
- Environment/location:
- Main actions:
- Dialogue/narration:
- Subtitle language:
- Mood and lighting:
- Camera style:
- Required effects:
- Existing GLB/GLTF assets:
- Export target: browser preview / WebM / MP4 (if supported)
- Device constraints: mobile-first (default)
