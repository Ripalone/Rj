# Three.js implementation notes

Use official Three.js documentation as the source of truth and verify APIs against the version selected for each project.

## Common imports (ES modules)

```js
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
```

## Scene skeleton

```js
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bb7c9);

const camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 0.1, 200);
camera.position.set(5, 4, 8);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.body.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xffffff, 0x65704f, 1.5));

const key = new THREE.DirectionalLight(0xffffff, 2.2);
key.position.set(5, 8, 4);
key.castShadow = true;
scene.add(key);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1, 0);
controls.update();

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}
animate();
```

## GLTF loading

```js
const loader = new GLTFLoader();
loader.load(
  '/models/character.glb',
  (gltf) => {
    scene.add(gltf.scene);
    if (gltf.animations.length) {
      const mixer = new THREE.AnimationMixer(gltf.scene);
      mixer.clipAction(gltf.animations[0]).play();
      // update mixer with clock delta in render loop
    }
  },
  (event) => {
    if (event.total) console.log(`${Math.round(event.loaded / event.total * 100)}%`);
  },
  (error) => console.error('Model failed to load:', error)
);
```

## Particle system guidance

For hundreds or thousands of particles, prefer one `THREE.Points` object with a `BufferGeometry` position attribute, or instanced meshes for shaped particles. Update typed arrays efficiently and mark attributes `needsUpdate = true`. Avoid creating a separate mesh for every particle.

## Camera and timeline

Keep a timeline function such as `updateSceneAt(timeSeconds)` that sets character pose, camera position/target, particles, and subtitle cue from a single time value. This makes playback, restart, and deterministic frame capture easier.

## Documentation links

- Three.js docs: https://threejs.org/docs/
- GLTFLoader: https://threejs.org/docs/pages/GLTFLoader.html
- OrbitControls: https://threejs.org/docs/pages/OrbitControls.html
- AnimationMixer: https://threejs.org/docs/pages/AnimationMixer.html
- WebGLRenderer: https://threejs.org/docs/pages/WebGLRenderer.html
